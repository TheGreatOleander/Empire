# Changelog
## v2.1
- Initial release of CodeSync XDA-GitHub Bridge.
