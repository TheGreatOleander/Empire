#!/bin/bash
echo "Setting up CodeSync environment..."
pip install -r requirements.txt
echo "Setup complete!"
